# SummerCampExercise
UTA High Energy Physics Summer Camp



Click the Clone Button on the top right-hand side of the screen to copy into your own directory, then edit the name of the project to UTA SC- firstname.lastname and set the status to public to allow the instructors to view your progress and help out when needed. Happy Coding!

***WARNING!!!***

If you use the old version you wont have the latest LHC data.  You might have read on the news that the old LHC data included evidence of broken electroweak symmetry.  We’ve weren’t happy with broken things in the exercise, so we wrote to the LHC and had them fix it.
